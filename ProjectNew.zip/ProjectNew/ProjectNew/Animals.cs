﻿using System;
namespace ProjectNew
{
    public class Animals
    {
        public int Chickens { get; set; }
        public int Pigs { get; set; }
        public int Cows { get; set; }
    }
}


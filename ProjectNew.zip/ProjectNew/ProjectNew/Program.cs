﻿
using ProjectNew;

Console.WriteLine(Calculation.GetTotalLegs());
Console.ReadLine();

﻿using System;
using Newtonsoft.Json;
namespace ProjectNew
{
    public class Calculation
    {
       private static void  GetAnimals(out int pigs,out int cows, out int chickens ) {
            using StreamReader r = new StreamReader(@"Data/Animals.json");
            string json = r.ReadToEnd();

            var animals = JsonConvert.DeserializeObject<Animals>(json);
            pigs = animals.Pigs;
            cows = animals.Cows;
            chickens = animals.Chickens;
	   }

       public static int GetTotalLegs() {
            GetAnimals(out int pigs, out int cows, out int chickens);
            return (pigs + cows) * 4 + (chickens*2);
	   }

            


    }
}

